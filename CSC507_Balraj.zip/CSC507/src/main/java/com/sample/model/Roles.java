package com.sample.model;

public enum Roles {
    Employee,SystemAdmin,Manager,Customer
}
