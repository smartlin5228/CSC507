
# Project Repo for CSC507

Make sure your git config is correct and ssh configuration is done

Please start by creating your own fork by clicking the `fork` button on the top right corner

Submitting the project by creating a pull request and reviewed by at least one of the other developer beforing merging the master


